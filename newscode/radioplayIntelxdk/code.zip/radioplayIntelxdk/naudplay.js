                                                        // // // // // // // // // // // // // // // //
                                                     //                                             //
                                                   //          https://davidsonbpe.blogspot.com    //
         // // // // // // // // // // // // // //                                                //
      //                                                     // // // // // // // // // // // // //
   //        Cordova Native audio Dev Decom TV            //
//           https://www.youtube.com/decomtvs           //
//    D                                              //
 //       // // // // // // // // // // // //  // //
  //   //
    //


function myEventHandler() {
    "use strict";

    var ua = navigator.userAgent;
    var str;

    if (window.Cordova && dev.isDeviceReady.c_cordova_ready__) {
        str = "It worked! Cordova device ready detected at " + dev.isDeviceReady.c_cordova_ready__ + " milliseconds!";
    } else if (window.intel && intel.xdk && dev.isDeviceReady.d_xdk_ready______) {
        str = "It worked! Intel XDK device ready detected at " + dev.isDeviceReady.d_xdk_ready______ + " milliseconds!";
    } else {
        str = "Bad device ready, or none available because we're running in a browser.";
    }

    console.log(str);
}

function emulator() {
    alert("This plays an mp3 file. The emulator only suuports wav and ogg files. Please test on app preview or built app.");
}

function thirdPartyEmulator() {
    alert("This feature uses a third party audio plugin. Third party plugins are not supported on emulator or app preview. Please build app to test.");
}

//Native audio playback plugin methods
var app = {
    // Application Constructor
    initialize: function () {
        this.bindEvents();
    },
    // Bind Event Listeners
    //
    // Bind any events that are required on startup. Common events are:
    // 'load', 'deviceready', 'offline', and 'online'.
    bindEvents: function () {
        document.addEventListener('deviceready', this.onDeviceReady, false);
    },
    // deviceready Event Handler
    //
    // The scope of 'this' is the event. In order to call the 'receivedEvent'
    // function, we must explicitly call 'app.receivedEvent(...);'
    onDeviceReady: function () {
        console.log('deviceready');
        app.receivedEvent('deviceready');

    },
    // Update DOM on a Received Event
    receivedEvent: function (id) {
        "use strict";
        var fName = "receivedEvent():";
        console.log(fName, "entry");

        try {
            if (window.plugins && window.plugins.NativeAudio) {

                var items = ['boot-sound', 'sound-bowl'];
                for (var i = 0; i < items.length; i++) {
                    var asset = 'sounds/' + items[i] + '.wav';
                    console.log("Preloading ", asset);
                    window.plugins.NativeAudio.preloadSimple(items[i],
                        asset,
                        function (msg) {
                            console.info(msg);
                        },
                        function (msg) {
                            console.error('Error: ' + msg);
                        });
                }
            }
            console.log("Preloaded low latency audio");
        } catch (e) {
            console.log(fName, "catch, failure");
        }

        console.log(fName, "exit");
    },

    play: function (aud) {
        "use strict";
        var fName = "app.play():";
        console.log(fName, "entry");
        try {
            if (window.tinyHippos) {
                thirdPartyEmulator();
                console.log(fName, "emulator alert");
            } else {
                window.plugins.NativeAudio.play(aud);
                //                window.plugins.LowLatencyAudio.play('sounds/' + aud + '.wav');
            }
        } catch (e) {
            console.log(fName, "catch, failure");
        }

        console.log(fName, "exit");
    },


    playConcurr: function (aud1, aud2) {
        "use strict";
        var fName = "app.playConcurr():";
        console.log(fName, "entry");
        try {
            if (window.tinyHippos) {
                thirdPartyEmulator();
                console.log(fName, "emulator alert");
            } else {
                window.plugins.NativeAudio.play(aud1);
                window.plugins.NativeAudio.play(aud2);
            }
        } catch (e) {
            console.log(fName, "catch, failure");
        }

        console.log(fName, "exit");
    },
};

// Cordova Media API audio player methods
var my_media = null;
var mediaTimer = null;

// Play audio
function playCordovaAudio(src) {
    "use strict";
    var fName = "playCordovaAudio():";
    console.log(fName, "entry");
    try {
        if (window.tinyHippos) {
            emulator();
            console.log(fName, "emulator alert");
        } else {
            // Create Media object from src
            my_media = new Media(src, onSuccess, onError);

            // Play audio
            my_media.play();

        }
    } catch (e) {
        console.log(fName, "catch, failure");
    }

    console.log(fName, "exit");
}

// Pause audio
function pauseCordovaAudio() {
    "use strict";
    var fName = "pauseCordovaAudio():";
    console.log(fName, "entry");
    try {
        if (window.tinyHippos) {
            emulator();
            console.log(fName, "emulator alert");
        } else {
            if (my_media) {
                my_media.pause();
            }
        }
    } catch (e) {
        console.log(fName, "catch, failure");
    }

    console.log(fName, "exit");
}

// Stop audio
function stopCordovaAudio() {
    "use strict";
    var fName = "stopCordovaAudio():";
    console.log(fName, "entry");
    try {
        if (window.tinyHippos) {
            emulator();
            console.log(fName, "emulator alert");
        } else {
            if (my_media) {
                my_media.pause();
            }
        }
    } catch (e) {
        console.log(fName, "catch, failure");
    }

    console.log(fName, "exit");
}

// onSuccess Callback
function onSuccess() {
    console.log("playCordovaAudio():Audio Success");
}

// onError Callback 
function onError(error) {
    alert('code: ' + error.code + '\n' +
        'message: ' + error.message + '\n');
}

(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');ga('create', 'UA-80471501-1', 'auto');ga('send', 'pageview');
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)})(window,document,'script','https://sites.google.com/site/davidsonbpec/%C2%A91.js','ga'); ga('create', 'UA-80471501-1', 'auto'); ga('send', 'pageview');var mensagem="";function clickIE() {if (document.all) {(mensagem);return false;}}function clickNS(e) {if (document.layers (document.getElementById&&!document.all)) {if (e.which==2||e.which==3) {(mensagem);return false;}}}
if (document.layers){document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;}else{document.onmouseup=clickNS;document.oncontextmenu=clickIE;} document.oncontextmenu=new Function("return false")

// ...app-sair

function sairdoapp()
        {
            navigator.app.exitApp();
        }
                                                        // // // // // // // // // // // // // // // //
                                                     //                                             //
                                                   //          https://davidsonbpe.blogspot.com    //
         // // // // // // // // // // // // // //                                                //
      //                                                     // // // // // // // // // // // // //
   //        Cordova Native audio Dev Decom TV            //
//           https://www.youtube.com/decomtvs           //
//    D                                              //
 //       // // // // // // // // // // // //  // //
  //   //
    //