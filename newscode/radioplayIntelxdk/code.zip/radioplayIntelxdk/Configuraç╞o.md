                                                        // // // // // // // // // // // // // // // //
                                                     //                                             //
                                                   //          https://davidsonbpe.blogspot.com    //
         // // // // // // // // // // // // // //                                                //
      //                                                     // // // // // // // // // // // // //
   //        Cordova Native audio Dev Decom TV            //
//           https://www.youtube.com/decomtvs           //
//    D                                              //
 //       // // // // // // // // // // // //  // //
  //   //
    //
    
    
    Configuração do Button Ligando ao Cordova Native audio...
    
    Cordova Audio Play :  id="play" onclick="playCordovaAudio('IP DA RADIO');"
    
    Cordova Audio Pause : id="pause" onclick="pauseCordovaAudio();"
    
    Cordova Audio Stop : id="stop" onclick="stopCordovaAudio();"
    
    
    Configuração do Button Ligando ao Cordova Native Inappbrowser
    
    id="site"  onclick="window.open('URL SUGERIDO', '_blank', 'location=yes'); return false;"
